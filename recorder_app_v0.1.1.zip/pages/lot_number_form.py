# -*- coding: utf-8 -*-
"""
Created on Wed May 13 14:12:48 2026

@author: grego
"""

import streamlit as st
import pandas as pd
from sqlalchemy import inspect
from datetime import datetime
from database import get_local_engine

def default_index(options, last_value):
    if last_value in options:
        return options.index(last_value)
    return 0

date_str = datetime.now().strftime("%Y-%m-%d")

engine = get_local_engine()
inspector = inspect(engine)

tab_input, tab_view = st.tabs(["Enter lot number information", 
                               "View / Filter Data"])

with tab_input:
    
    st.header("Bucket Log")
    # Date
    date = date_str
    st.write(f'Today\'s Date: {date}')

    last = st.session_state.get("last_lot", {})
    
    
    
    with st.form("Lot Number Form"):
        
        # FormStatus
        form_status = ['Open', 'Need to Close', 'Closed']
        formStatus = st.selectbox('Form Status', form_status)
        
        # Sites
        sites_select = ["BPA"]
        site = st.selectbox('Site',
                            sites_select,
                            index=default_index(sites_select, last.get("Site")))

        # Squares
        lot_squares = pd.read_sql(
            '''SELECT DISTINCT Square FROM strat_unit_form''',
            engine
            )
        square_options = lot_squares["Square"].tolist()
        squares = st.selectbox(
            "Square",
            square_options,
            index=default_index(square_options, last.get("Square"))
            )

        # Quad
        quad_options = ['All', 'NW', 'NE', 'SW', 'SE']
        quads = st.selectbox(
            "Quad",
            quad_options,
            index=default_index(quad_options, last.get("Quadrant"))
            )

        # Excavator
        lot_ex = pd.read_sql(
            '''SELECT DISTINCT Excavator FROM strat_unit_form''',
            engine
            )
        ex_options = lot_ex["Excavator"].tolist()
        ex = st.selectbox(
            "Excavator",
            ex_options,
            index=default_index(ex_options, last.get("Excavator"))
            )

        # Lot number
        lots = st.number_input("Lot Number")

        #feature type
        features = ['General Archaeological Layer', 'Cleaning', 'Profile Collapse',
                    'Overburden', 'Geogenic', 'Combustion Feature', 'Specialist Sample']
        feat = st.selectbox(
            "Feature Type",
            features,
            index=default_index(features, 
                                last.get("FeatureType"))
            )

        # Strat unit
        strat = pd.read_sql(
            '''SELECT DISTINCT StratUnitName FROM strat_unit_form''',
            engine
            )
        strat_options = strat["StratUnitName"].tolist()
        strat_select = st.selectbox(
            "Strat Unit Name",
            strat_options,
            index=default_index(strat_options, last.get("StratUnitName"))
            )
        
        # bulk sample
        bulk = st.number_input("Bulk Sample Number")
        
        # bucket count
        buck_count = st.number_input("Total Full Bucket Count")
        
        # bucket depth
        buck_depth = st.number_input("Depth Below Top of Final Bucket (cm)")
        
        # Comment
        buck_comm = st.text_input("Comment")
        
        # Hearth ID
        hearth_id = st.text_input("Hearth Element ID")
        
            
        
        
        submitted = st.form_submit_button("Save")

        if submitted:

            df = pd.DataFrame([{
                'FormStatus': formStatus,
                "SiteName": site,
                "Date": date,
                "Square":squares,
                "Quadrant": quads,
                "Excavator": ex,
                'FeatureType': feat,
                "LotNumber": lots,
                "StratUnitName": strat_select,
                'BulkSampleNumber': bulk,
                'FullBucketCount': buck_count,
                'DepthBelowBucketTop': buck_depth,
                'BucketCountComment': buck_comm,
                'HearthElementID': hearth_id
                }])

            df.to_sql(
                "lot_number_form",
                engine,
                if_exists="append",
                index=False
                )

            st.session_state["last_lot"] = submitted
            st.success("Saved")
        
        
        
with tab_view:
    st.header("View Tables")
    
    col1, col2 = st.columns([1,4])
    
    
    df = pd.read_sql(
        "SELECT * FROM lot_number_form",
        engine
    )

    with col1:
        # Lot filter
        status = ["All"] + sorted(df["FormStatus"].dropna().unique().tolist())
        status_filter = st.selectbox("Form Status", status)
        
        # Lot filter
        lots = ["All"] + sorted(df["LotNumber"].dropna().unique().tolist())
        lot_filter = st.selectbox("Lot Number", lots)

        # Square filter
        squares = ["All"] + sorted(df["Square"].dropna().unique().tolist())
        square_filter = st.selectbox("Square", squares)
    
        # Quad
        quad = ["All"] + sorted(df["Quadrant"].dropna().unique().tolist())
        quad_filter = st.selectbox("Quad", quad)
    
        # Date
        date = ["All"] + sorted(df["Date"].dropna().unique().tolist())
        date_filter = st.selectbox("Date", date)
        
        # Excavator
        exc = ["All"] + sorted(df["Excavator"].dropna().unique().tolist())
        exc_filter = st.selectbox("Excavator", exc)
        
        # Strat Unit
        strat = ["All"] + sorted(df["StratUnitName"].dropna().unique().tolist())
        strat_filter = st.selectbox("Strat Unit Name", strat)
        
        # feature filter
        feat = ["All"] + sorted(df["FeatureType"].dropna().unique().tolist())
        feat_filter = st.selectbox("Feature Type", feat)
        
        # feature filter
        bulk = ["All"] + sorted(df["BulkSampleNumber"].dropna().unique().tolist())
        bulk_filter = st.selectbox("Bulk Sample Number", bulk)
        
        
    with col2:
        filtered = df.copy()
        
        if status_filter != "All":
            filtered = filtered[filtered["FormStatus"] == status_filter]

        if lot_filter != "All":
            filtered = filtered[filtered["LotNumber"] == lot_filter]

        if square_filter != "All":
            filtered = filtered[filtered["Square"] == square_filter]
            
        if date_filter != "All":
            filtered = filtered[filtered["Date"] == date_filter]
            
        if quad_filter != "All":
            filtered = filtered[filtered["Quadrant"] == quad_filter]
            
        if exc_filter != "All":
            filtered = filtered[filtered["Excavator"] == exc_filter]
            
        if strat_filter != "All":
            filtered = filtered[filtered["StratUnitName"] == strat_filter]
            
        if feat_filter != "All":
            filtered = filtered[filtered["FeatureType"] == feat_filter]
            
        if bulk_filter != "All":
            filtered = filtered[filtered["BulkSampleType"] == bulk_filter]
            
            
        st.subheader("Filtered Results")

        st.dataframe(filtered, use_container_width=True)

        st.write(f"Rows: {len(filtered)}")

        st.download_button("Export CSV", filtered.to_csv(index=False), 
                           f"lot_number_{date_str}.csv")
        
        