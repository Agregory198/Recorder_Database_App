# -*- coding: utf-8 -*-
"""
Created on Wed May 13 16:05:16 2026

@author: grego
"""

import streamlit as st
import pandas as pd
from sqlalchemy import inspect
from datetime import datetime
from database import get_local_engine

def default_index(options, last_value):
    if last_value in options:
        return options.index(last_value)
    return 0

date_str = datetime.now().strftime("%Y-%m-%d")

engine = get_local_engine()
inspector = inspect(engine)

tab_input, tab_view = st.tabs(["Enter strat unit information", 
                               "View / Filter Data"])

with tab_input:
    
    st.header("Strat Unit Form")
    
    # Date
    date = date_str
    st.write(f'Today\'s Date: {date}')
    
    st.header('Opening')

    last = st.session_state.get("last_strat", {})
    
    if "sample_number" not in st.session_state:
        st.session_state.sample_number = 1
        
    if "last_lot_number" not in st.session_state:
        st.session_state.last_lot_number = 1
    
    col1, col2 = st.columns(2)
    
    
    with st.form("Strat Unit Form"):
        
        with col1:
            
            
            # Sites
            sites_select = ["BPA"]
            site = st.selectbox('Site',
                                sites_select,
                                index=default_index(sites_select, last.get("Site")))
            
            exc = st.text_input(
                'Excavator(s)'
                )
            
            # Strat unit
            strat_select = st.text_input(
                "Strat Unit Name"
                )

            # Squares
            squares = st.text_input(
                "Square"
                )
            
            # context
            context = st.text_input(
                "Context (MALAPP)"
                )

        with col2:
            col1_2, col2_2 = st.columns(2)
            
            with col1_2:
                st.subheader('Lot Numbers')
                
                lot_nw = st.number_input("NW",
                                         format="%.0f")
                lot_ne = st.number_input("NE",
                                         format="%.0f")
                lot_sw = st.number_input("SW",
                                         format="%.0f")
                lot_se = st.number_input("SE",
                                         format="%.0f")
                
            with col2_2:
                st.subheader('Bulk Samples')
                
                bulk_nw = st.number_input("NW", key = 'bulk1',
                                         format="%.0f")
                bulk_ne = st.number_input("NE", key = 'bulk2',
                                         format="%.0f")
                bulk_sw = st.number_input("SW", key = 'bulk3',
                                         format="%.0f")
                bulk_se = st.number_input("SE", key = 'bulk4',
                                         format="%.0f")
            # Residue protocol
            res = st.checkbox("Residue Protocol?")
        
        
    st.header("Mid-Excavation")
    col3, col4 = st.columns(2)
    with col3:
            
            mid_photo = st.checkbox("Midstrat Photo?")
            mid_photo_series = st.text_input("Mid Strat Photo Series Number")
            
            
            spec_samp = st.checkbox("Specialist Sample?")
            
    with col4:
            
            col5_1, col5_2 = st.columns(2)
            with col5_1:
                st.subheader("Bulk Samples Taken")
                
                nw_taken = st.checkbox("NW")
                ne_taken = st.checkbox("NE")
                sw_taken = st.checkbox("SW")
                se_taken = st.checkbox("SE")
                
            with col5_2:
                st.subheader("Bulk Samples shot")
                
                nw_shot = st.checkbox("NW", key = 'shot1')
                ne_shot = st.checkbox("NE", key = 'shot2')
                sw_shot = st.checkbox("SW", key = 'shot3')
                se_shot = st.checkbox("SE", key = 'shot4')
                
        
    st.header("Closing")
    
    final_out = st.checkbox('Final Outline Taken?')
    
    cont_above = st.text_input("Contiguous Strat Units Above")
    cont_below = st.text_input("Contiguous Strat Units Below")
    equivalent = st.text_input("Equivalent Strat Units")
    agg_assign_exc = st.text_input("Stratigraphic Aggregate Assignment by Excavator")
    sub_agg_assign_exc = st.text_input("Sub-Aggregate Assignment by Excavator")
    
    col6, col7 = st.columns(2)
    with col6:
        # general diagnosis
        gens = ['General Archaeological Layer', 'Cleaning', 'Profile Collapse',
                'Profile Cleaning', 'Erosional Fill', 'General Cleaning', 'Burrow',
                'Erosion Gully', 'Geogenic Layer', 'Distrubance', 'Other'
                'Overburden', 'Combustion Feature']
        
        gen_diag = st.selectbox(
            "General Diagnosis",
            gens
            )
        
    with col7:
        diag_comment = st.text_input("Detailed Diagnosis and Justification")
        
    st.subheader("Geological Characteristics")
    
    mun_col = st.text_input("Munsel Color")
    texture = st.text_input("Texture")
    moist = st.text_input('Moisture Level')
    nat_incl = st.text_input("Natural Inclusions")
    nat_form = st.text_input("Natural Formations")
    dist = st.text_input("Disturbances")
    
    st.subheader("Archaeological Characteristics")
    
    art_type = st.text_input("Observed Artifact Types")
    
    burn_feat = st.checkbox("Burned Feature?")
    
    other_comment = st.text_input("Other Comments")
    
    
    st.header("Director Assignment")
    col8, col9 = st.columns([1,2])
    with col8:
        agg_assign_dir = st.text_input("Director Aggregate Assignment")
        sub_agg_assign_dir = st.text_input("Director Sub-Aggregate Assignment")
        
    with col9:
        dir_comments = st.text_input("Director Commnets on Assignments")