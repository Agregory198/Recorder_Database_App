# -*- coding: utf-8 -*-
"""
Created on Wed May 13 14:48:13 2026

@author: grego
"""

import streamlit as st
import pandas as pd
from sqlalchemy import inspect
from datetime import datetime
from database import get_local_engine

def default_index(options, last_value):
    if last_value in options:
        return options.index(last_value)
    return 0

date_str = datetime.now().strftime("%Y-%m-%d")

engine = get_local_engine()
inspector = inspect(engine)

tab_input, tab_view = st.tabs(["Enter photo information", 
                               "View / Filter Data"])

with tab_input:
    
    st.header("Photo Form")
    # Date
    date = date_str
    st.write(f'Today\'s Date: {date}')

    last = st.session_state.get("last_photo", {})
    
    if "photo_series" not in st.session_state:
        st.session_state.photo_series = 1
        
    if "camera_file" not in st.session_state:
        st.session_state.camera_file = 1
        
    if "photo_number" not in st.session_state:
        st.session_state.photo_number = 1
    
    col1, col2, col3 = st.columns(3)
    
    
    with st.form("Digital Photo Form"):
    
        with col1:
            st.subheader('Provenience Info')
    
            # Sites
            sites_select = ["BPA"]
            site = st.selectbox('Site',
                                sites_select,
                                index=default_index(sites_select, last.get("Site")))
            
            # Photographer
            ex = st.text_input("Photographer")
            
            # direction shot
            directions = ['N', 'E', 'S', 'W']
            direct = st.selectbox(
                "Direction Shot From",
                directions,
                index=default_index(directions, last.get("DirectionOfShot(From)"))
                )
    
            # flash?
            flash = ['Y', 'N']
            flash_det = st.selectbox(
                "Flash?",
                flash,
                index=default_index(directions, last.get("Flash?"))
                )
            
            # PhotoType
            photo_types = ['Analysis', 'Bad Shot', 'End of Season', 'Feature',
                           'Mid-Strat', 'Opening', 'Recreational', 'Rectified',
                           'Sample', 'Section', 'Start of Season', 'Unexcavated']
            photo = st.selectbox(
                "Photo Type",
                photo_types,
                index=default_index(photo_types, last.get("PhotoType"))
                )
            
            
        with col2:
            st.subheader("Photo Name Info")
            
            
            # PhotoType
            camera_types = ['90D', 'R']
            camera = st.selectbox(
                "Photo Type",
                camera_types,
                index=default_index(camera_types, last.get("Camera"))
                )
            
            
            # Photo series
            series = st.number_input(
                "Photo Series",
                value=st.session_state.photo_series,
                step=1
                )
            
            # Camera file
            camera_f = st.number_input(
                "Camera File Number",
                value=st.session_state.camera_file,
                step=1
                )
            
            # photo number
            photo_num = st.number_input(
                "Photo Number",
                value=st.session_state.photo_number,
                step=1
                )
            
            
            
        with col3:
            
            st.subheader("Misc Infor")
    
            # Squares
            lot_squares = pd.read_sql(
                '''SELECT DISTINCT Square FROM strat_unit_form''',
                engine
                )
            square_options = lot_squares["Square"].tolist()
            squares = st.selectbox(
                "Square",
                square_options,
                index=default_index(square_options, last.get("Square"))
                )
    
            # Quad
            quad_options = ['All', 'NW', 'NE', 'SW', 'SE']
            quads = st.selectbox(
                "Quad",
                quad_options,
                index=default_index(quad_options, last.get("Quadrant"))
                )
    
            # Lot number
            lot_num = pd.read_sql(
                '''SELECT DISTINCT LotNumber FROM lot_number_form''',
                engine
                )
            lot_num_options = lot_num["LotNumber"].tolist()
            lots = st.selectbox(
                "Lot Number",
                lot_num_options,
                index=default_index(lot_num_options, last.get("LotNumber"))
                )
            
            # Strat unit
            strat = pd.read_sql(
                '''SELECT DISTINCT StratUnitName FROM strat_unit_form''',
                engine
                )
            strat_options = strat["StratUnitName"].tolist()
            strat_select = st.selectbox(
                "Strat Unit Name",
                strat_options,
                index=default_index(strat_options, last.get("StratUnitName"))
                )
    
    
            sect = st.text_input("Section Line")
            
            ext = st.text_input("Section Extent")
            
            spec_samp = st.number_input("Specialist Sample Number")
            
            hearth_id = st.text_input("Hearth Element ID")
            
            comments = st.text_input("Comments")
            
        
        submitted = st.form_submit_button("Save")
        
        if submitted:

            df = pd.DataFrame([{
                "Date": date,
                "SiteName": site,
                'PhotoSeries': series,
                'PhotoNumber': photo_num,
                'Photographer': ex,
                'Camera': camera,
                'CameraFileName': camera_f,
                "StratUnitName": strat_select,
                "LotNumber": lots,
                "Square":squares,
                "Quadrant": quads,
                'HearthElementID': hearth_id,
                'DirectionOfShot(From)': direct,
                'Flash?':flash_det,
                'SampleNumber': spec_samp,
                'PhotoType': photo,
                'Line': sect,
                'Extent': ext,
                'Comments': comments
                }])

            df.to_sql(
                "digital_photography_form",
                engine,
                if_exists="append",
                index=False
                )

            st.session_state["last_photo"] = submitted

            st.session_state.photo_series += 1
            st.success("Saved and incremented photo series")
            
            st.session_state.camera_file += 1
            st.success("Saved and incremented camera file")
            
            st.session_state.photo_number += 1
            st.success("Saved and incremented photo number")
            
            
            
            
with tab_view:
    st.header("View Tables")
    
    col1, col2 = st.columns([1,4])
    
    
    df = pd.read_sql(
        "SELECT * FROM digital_photography_form",
        engine
    )

    with col1:
        # Lot filter
        lots = ["All"] + sorted(df["LotNumber"].dropna().unique().tolist())
        lot_filter = st.selectbox("Lot Number", lots)

        # Square filter
        squares = ["All"] + sorted(df["Square"].dropna().unique().tolist())
        square_filter = st.selectbox("Square", squares)
    
        # Quad
        quad = ["All"] + sorted(df["Quadrant"].dropna().unique().tolist())
        quad_filter = st.selectbox("Quad", quad)
    
        # Date
        date = ["All"] + sorted(df["Date"].dropna().unique().tolist())
        date_filter = st.selectbox("Date", date)
        
        # Strat Unit
        strat = ["All"] + sorted(df["StratUnitName"].dropna().unique().tolist())
        strat_filter = st.selectbox("Strat Unit Name", strat)
        
        # feature filter
        feat = ["All"] + sorted(df["HearthElementID"].dropna().unique().tolist())
        feat_filter = st.selectbox("Hearlth Element ID", feat)
        
        # feature filter
        bulk = ["All"] + sorted(df["SampleNumber"].dropna().unique().tolist())
        bulk_filter = st.selectbox("Specialist Sample Number", bulk)
        
        
    with col2:
        filtered = df.copy()

        if lot_filter != "All":
            filtered = filtered[filtered["LotNumber"] == lot_filter]

        if square_filter != "All":
            filtered = filtered[filtered["Square"] == square_filter]
            
        if date_filter != "All":
            filtered = filtered[filtered["Date"] == date_filter]
            
        if quad_filter != "All":
            filtered = filtered[filtered["Quadrant"] == quad_filter]
            
        if strat_filter != "All":
            filtered = filtered[filtered["StratUnitName"] == strat_filter]
            
        if feat_filter != "All":
            filtered = filtered[filtered["FeatureType"] == feat_filter]
            
        if bulk_filter != "All":
            filtered = filtered[filtered["BulkSampleType"] == bulk_filter]
            
            
        st.subheader("Filtered Results")

        st.dataframe(filtered, use_container_width=True)

        st.write(f"Rows: {len(filtered)}")

        st.download_button("Export CSV", filtered.to_csv(index=False), 
                           f"photo_form_{date_str}.csv")