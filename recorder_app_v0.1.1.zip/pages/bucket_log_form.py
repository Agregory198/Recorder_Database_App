# -*- coding: utf-8 -*-
"""
Created on Wed May 13 12:14:28 2026

@author: grego
"""


import streamlit as st
import pandas as pd
from sqlalchemy import inspect
from datetime import datetime
from database import get_local_engine

def default_index(options, last_value):
    if last_value in options:
        return options.index(last_value)
    return 0

date_str = datetime.now().strftime("%Y-%m-%d")

engine = get_local_engine()
inspector = inspect(engine)

tab_input, tab_view = st.tabs(["Enter bucket information", 
                               "View / Filter Data"])



with tab_input:
    st.header("Bucket Log")
    # Date
    date = date_str
    st.write(f'Today\'s Date: {date}')
    
    col1, col2 = st.columns(2)
    last = st.session_state.get("last_bucket", {})
    
    with st.form("Bucket Log Form"):
    
        with col1:
            st.subheader('Lot Information')
    
    
            # Sites
            sites_select = ["BPA"]
            site = st.selectbox('Site',
                                sites_select)
    
    
            # Squares
            lot_squares = pd.read_sql(
                '''SELECT DISTINCT Square FROM strat_unit_form''',
                engine
                )
            square_options = lot_squares["Square"].tolist()
            squares = st.selectbox(
                "Square",
                square_options,
                index=default_index(square_options, last.get("Square"))
                )
    
    
            # Quad
            quad_options = ['All', 'NW', 'NE', 'SW', 'SE']
            quads = st.selectbox(
                "Quad",
                quad_options,
                index=default_index(quad_options, last.get("Quad"))
                )
    
    
            # Excavator
            lot_ex = pd.read_sql(
                '''SELECT DISTINCT Excavator FROM strat_unit_form''',
                engine
                )
            ex_options = lot_ex["Excavator"].tolist()
            ex = st.selectbox(
                "Excavator",
                ex_options,
                index=default_index(ex_options, last.get("Excavator"))
                )
    
    
            # Lot number
            lot_num = pd.read_sql(
                '''SELECT DISTINCT LotNumber FROM lot_number_form''',
                engine
                )
            lot_num_options = lot_num["LotNumber"].tolist()
            lots = st.selectbox(
                "Lot Number",
                lot_num_options,
                index=default_index(lot_num_options, last.get("LotNumber"))
                )
    
    
            # Lot number additional
            lot_num_ad = pd.read_sql(
                '''SELECT DISTINCT LotNumber FROM lot_number_form''',
                engine
                )
            lot_num_options_ad = lot_num_ad["LotNumber"].tolist()
            lots_ad = st.selectbox(
                "Additional Lot Number",
                lot_num_options_ad,
                index=default_index(lot_num_options_ad, 
                                    last.get("AdditionalLotNumber"))
                )
            
            
            # Strat unit
            strat = pd.read_sql(
                '''SELECT DISTINCT StratUnitName FROM strat_unit_form''',
                engine
                )
            strat_options = strat["StratUnitName"].tolist()
            strat_select = st.selectbox(
                "Strat Unit Name",
                strat_options,
                index=default_index(strat_options, last.get("StratUnitName"))
                )
            
        with col2:
            st.subheader('Bucket Information')
                
    
            # BucketNumber
            bucket_num = st.text_input("Bucket Number")
            # Bucket type
            bucket_typ = st.text_input("Bucket Type")
            # Bucket weight
            bucket_wt = st.number_input("Bucket Weight (kg)")
            # Bucket depth
            bucket_depth = st.number_input("Bucket Depth (cm)")
            
            
        submitted = st.form_submit_button("Save")

        if submitted:

            df = pd.DataFrame([{
                "SiteName": site,
                "Date": date,
                "Square":squares,
                "Quad": quads,
                "Excavator": ex,
                "LotNumber": lots,
                "StratUnitName": strat_select,
                "AdditionalLotNumber": lots_ad,
                
                "BucketNumber": bucket_num,
                "BucketType": bucket_typ,
                "Weight": bucket_wt,
                "BucketDepth": bucket_depth
                }])

            df.to_sql(
                "lithics",
                engine,
                if_exists="append",
                index=False
                )

            st.session_state["last_bucket"] = submitted
            st.success("Saved")
            
with tab_view:
    st.header("View Tables")
    
    col1, col2 = st.columns([1,4])
    
    
    df = pd.read_sql(
        "SELECT * FROM bucket_log_form",
        engine
    )

    with col1:
        # Lot filter
        lots = ["All"] + sorted(df["LotNumber"].dropna().unique().tolist())
        lot_filter = st.selectbox("Lot Number", lots)

        # Square filter
        squares = ["All"] + sorted(df["Square"].dropna().unique().tolist())
        square_filter = st.selectbox("Square", squares)
    
        # Quad
        quad = ["All"] + sorted(df["Quad"].dropna().unique().tolist())
        quad_filter = st.selectbox("Quad", quad)
    
        # Date
        date = ["All"] + sorted(df["Date"].dropna().unique().tolist())
        date_filter = st.selectbox("Date", date)
        
        # Excavator
        exc = ["All"] + sorted(df["Excavator"].dropna().unique().tolist())
        exc_filter = st.selectbox("Excavator", exc)
        
        # Strat Unit
        strat = ["All"] + sorted(df["StratUnitName"].dropna().unique().tolist())
        strat_filter = st.selectbox("Strat Unit Name", strat)
        
        
    with col2:
        filtered = df.copy()

        if lot_filter != "All":
            filtered = filtered[filtered["LotNumber"] == lot_filter]

        if square_filter != "All":
            filtered = filtered[filtered["Square"] == square_filter]
            
        if date_filter != "All":
            filtered = filtered[filtered["Date"] == date_filter]
            
        if quad_filter != "All":
            filtered = filtered[filtered["Quad"] == quad_filter]
            
        if exc_filter != "All":
            filtered = filtered[filtered["Excavator"] == exc_filter]
            
        if strat_filter != "All":
            filtered = filtered[filtered["StratUnitName"] == strat_filter]
            
            
        st.subheader("Filtered Results")

        st.dataframe(filtered, use_container_width=True)

        st.write(f"Rows: {len(filtered)}")

        st.download_button("Export CSV", filtered.to_csv(index=False), 
                           f"bucket_log_{date_str}.csv")