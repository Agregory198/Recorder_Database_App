# -*- coding: utf-8 -*-
"""
Created on Wed May 13 15:32:06 2026

@author: grego
"""

import streamlit as st
import pandas as pd
from sqlalchemy import inspect
from datetime import datetime
from database import get_local_engine

def default_index(options, last_value):
    if last_value in options:
        return options.index(last_value)
    return 0

date_str = datetime.now().strftime("%Y-%m-%d")

engine = get_local_engine()
inspector = inspect(engine)

tab_input, tab_view = st.tabs(["Enter specialist information", 
                               "View / Filter Data"])

with tab_input:
    
    st.header("Specialist Sample Form")
    # Date
    date = date_str
    st.write(f'Today\'s Date: {date}')

    last = st.session_state.get("last_spec", {})
    
    if "sample_number" not in st.session_state:
        st.session_state.sample_number = 1
        
    if "last_lot_number" not in st.session_state:
        st.session_state.last_lot_number = 1
    
    col1, col2 = st.columns(2)
    
    
    with st.form("Specialist Sample Form"):
    
        with col1:
            st.subheader('Provenience Info')
            
            
            
            # Sites
            sites_select = ["BPA"]
            site = st.selectbox('Site',
                                sites_select,
                                index=default_index(sites_select, last.get("Site")))
            
            # Lot number
            lots = st.number_input("Lot Number",
                                   value=st.session_state.last_lot_number,
                                   step=1
                                   )
            
            # Strat unit
            strat = pd.read_sql(
                '''SELECT DISTINCT StratUnitName FROM strat_unit_form''',
                engine
                )
            strat_options = strat["StratUnitName"].tolist()
            strat_select = st.selectbox(
                "Strat Unit Name",
                strat_options,
                index=default_index(strat_options, last.get("StratUnitName"))
                )

            # Squares
            lot_squares = pd.read_sql(
                '''SELECT DISTINCT Square FROM strat_unit_form''',
                engine
                )
            square_options = lot_squares["Square"].tolist()
            squares = st.selectbox(
                "Square",
                square_options,
                index=default_index(square_options, last.get("Square"))
                )

            # Quad
            quad_options = ['All', 'NW', 'NE', 'SW', 'SE']
            quads = st.selectbox(
                "Quad",
                quad_options,
                index=default_index(quad_options, last.get("Quadrant"))
                )

            # General description
            desc = st.text_input("General Description")
            
        with col2:
            st.subheader("Specialist Info")
            
            # sample number
            samp_num = st.number_input(
                "Sample Number",
                value=st.session_state.sample_number,
                step=1
                )
            
            spec_id = st.text_input(
                "Specialist Sample ID"
                )
            
            
            st.subheader("Sample Type")
            
            col3, col4 = st.columns(2)
            with col3:
                c14 = st.checkbox("C14")
                ftir = st.checkbox("FTIR")
                gen_geo = st.checkbox("General Geological")
                mag = st.checkbox("Magnetic")
                micro = st.checkbox("Micromorphology")
                dna = st.checkbox("DNA")
                
            with col4:
                osl = st.checkbox("OSL")
                phyt = st.checkbox("Phytolith")
                tl = st.checkbox("TL")
                u_ser = st.checkbox("U-Series")
                cos = st.checkbox("Cosmogenic")
                crypt = st.checkbox("Cryptotephra")
                
                
            
            hearth_id = st.text_input("Hearth Element ID")
            
        comments = st.text_input("Comments")
            
            
        submitted = st.form_submit_button("Save")
        
        if submitted:

            df = pd.DataFrame([{
                "Date": date,
                "SiteName": site,
                "StratUnitName": strat_select,
                "LotNumber": lots,
                "Square":squares,
                "Quadrant": quads,
                'SampleNumber': samp_num,
                'SpecialistSampleID': spec_id,
                'HearthElementID': hearth_id,
                'GeneralDescription':desc,
                'C14': c14,
                'OSL':osl,
                'TL':tl,
                'U-Series':u_ser,
                'FTIR': ftir,
                'GeneralGeological':gen_geo,
                'Magnetic':mag,
                'Micromorphology': micro,
                'Phytolith': phyt,
                'Cosmogenic': cos,
                'DNA':dna,
                'Cryptotephra': crypt,
                'Comments': comments
                }])

            df.to_sql(
                "specialist_sample_form",
                engine,
                if_exists="append",
                index=False
                )

            st.session_state["last_spec"] = submitted
            
            st.session_state.sample_number = samp_num
            
            
with tab_view:
    st.header("View Tables")
    
    col1, col2 = st.columns([1,4])
    
    
    df = pd.read_sql(
        "SELECT * FROM digital_photography_form",
        engine
    )

    with col1:
        # Lot filter
        lots = ["All"] + sorted(df["LotNumber"].dropna().unique().tolist())
        lot_filter = st.selectbox("Lot Number", lots)

        # Square filter
        squares = ["All"] + sorted(df["Square"].dropna().unique().tolist())
        square_filter = st.selectbox("Square", squares)
    
        # Quad
        quad = ["All"] + sorted(df["Quadrant"].dropna().unique().tolist())
        quad_filter = st.selectbox("Quad", quad)
    
        # Date
        date = ["All"] + sorted(df["Date"].dropna().unique().tolist())
        date_filter = st.selectbox("Date", date)
        
        # Strat Unit
        strat = ["All"] + sorted(df["StratUnitName"].dropna().unique().tolist())
        strat_filter = st.selectbox("Strat Unit Name", strat)
        
        # feature filter
        feat = ["All"] + sorted(df["HearthElementID"].dropna().unique().tolist())
        feat_filter = st.selectbox("Hearlth Element ID", feat)
        
        # feature filter
        bulk = ["All"] + sorted(df["SampleNumber"].dropna().unique().tolist())
        bulk_filter = st.selectbox("Specialist Sample Number", bulk)
        
        
    with col2:
        filtered = df.copy()

        if lot_filter != "All":
            filtered = filtered[filtered["LotNumber"] == lot_filter]

        if square_filter != "All":
            filtered = filtered[filtered["Square"] == square_filter]
            
        if date_filter != "All":
            filtered = filtered[filtered["Date"] == date_filter]
            
        if quad_filter != "All":
            filtered = filtered[filtered["Quadrant"] == quad_filter]
            
        if strat_filter != "All":
            filtered = filtered[filtered["StratUnitName"] == strat_filter]
            
        if feat_filter != "All":
            filtered = filtered[filtered["FeatureType"] == feat_filter]
            
        if bulk_filter != "All":
            filtered = filtered[filtered["BulkSampleType"] == bulk_filter]
            
            
        st.subheader("Filtered Results")

        st.dataframe(filtered, use_container_width=True)

        st.write(f"Rows: {len(filtered)}")

        st.download_button("Export CSV", filtered.to_csv(index=False), 
                           f"specialist_samples_{date_str}.csv")
            
            
            
            
            
            
            
            
            

            