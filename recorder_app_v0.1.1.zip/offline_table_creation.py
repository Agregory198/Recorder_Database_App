# -*- coding: utf-8 -*-
"""
Created on Wed May 13 11:31:27 2026

@author: grego
"""

import sys
from pathlib import Path
import sqlite3
from database import get_db_path


DB_PATH = get_db_path()

DB_PATH.parent.mkdir(parents=True, exist_ok=True)

def initialize_sqlite_DB():

    conn = sqlite3.connect(str(DB_PATH))
    cursor = conn.cursor()


    cursor.executescript("""

CREATE TABLE IF NOT EXISTS bucket_log_form (
	daily_ID INTEGER PRIMARY KEY AUTOINCREMENT,
    ID int unique,
    `Date` varchar(150),
    Site varchar(200),
    Excavator varchar(50),
    Square varchar(50),
    Quad varchar(50),
    StratUnitName varchar(255),
    LotNumber int,
    AdditionalLotNumber varchar(150),
    Weight float,
    BucketDepth float,
    BucketNumber float,
    BucketType varchar(255)
);

CREATE TABLE IF NOT EXISTS lot_number_form (
	daily_ID INTEGER PRIMARY KEY AUTOINCREMENT,
    FormStatus varchar(50),
    SiteName varchar(150),
    `Date` varchar(255),
    StratUnitName varchar(150),
    LotNumber int UNIQUE,
    Square varchar(150),
    Quadrant varchar(150),
    Excavator varchar(255),
    FeatureType varchar(255),
    BulkSampleNumber float,
    `Comment` varchar(255),
    FullBucketCount float,
    DepthBelowBucketTop float,
    BucketCountComment varchar(255),
    HearthElementID varchar(255)
);

CREATE TABLE IF NOT EXISTS digital_photography_form (
	daily_ID INTEGER PRIMARY KEY AUTOINCREMENT,
    `Date` varchar(150),
    SiteName varchar(255),
    PhotoSeries int,
    PhotoNumber int UNIQUE,
    Photographer varchar(255),
    Camera varchar(255),
    CameraFileName varchar(255),
    StratUnitName varchar(255),
    LotNumber int,
    Square varchar(255),
    Quadrant varchar(255),
    HearthElementID varchar(255),
    `DirectionOfShot(From)` varchar(255),
    `Flash?` varchar(50),
    SampleNumber int,
    PhotoType varchar(255),
    Line varchar(255),
    Extent varchar(255),
    Comments varchar(1000)
);

CREATE TABLE IF NOT EXISTS specialist_sample_form (
	daily_ID INTEGER PRIMARY KEY AUTOINCREMENT,
    `Date` varchar(150),
    SiteName varchar(255),
    StratUnitName varchar(255),
    LotNumber int,
    Square varchar(255),
    Quadrant varchar(255),
    SampleNumber float UNIQUE,
    SpecialistSampleID varchar(500),
    HearthElementID varchar(255),
    GeneralDescription varchar(1000),
    C14 boolean,
    C14Status varchar(255),
    OSL boolean,
    OSLStatus varchar(255),
    TL boolean,
    `U-series` boolean,
    `U-seriesStatus` varchar(255),
    FTIR boolean,
    FTIRStatus varchar(255),
    GeneralGeological boolean,
    GeneralGeoStatus varchar(255),
    Magnetic boolean,
    MagneticStatus varchar(255),
    MagneticOrientation varchar(255),
    Micromorphology boolean,
    MicromorphologyStatus varchar(255),
    Phytolith boolean,
    PhytolithStatus varchar(255),
    Cosmogenic boolean,
    CosmogenicStatus varchar(255),
    DNA boolean,
    DNAstatus varchar(255),
    Cryptotephra boolean,
    CryptotephraStatus varchar(255),
    `Status` varchar(255),
    LowResOnWeb boolean,
    HighResOnWeb boolean,
    Comments varchar(1000)
);


CREATE TABLE IF NOT EXISTS strat_unit_form (
	daily_ID INTEGER PRIMARY KEY AUTOINCREMENT,
    `Date` varchar(255),
    FormStatus varchar(255),
    SiteName varchar(255),
    StratUnitName varchar(255) UNIQUE,
    `Context` varchar(255),
    Square varchar(255),
    Excavator varchar(255),
    FieldDirectorStratAggregateAssignment varchar(255),
    FieldDirectorSubAggregateAssignment varchar(255),
    FieldExcavatorStratAggregateAssignment varchar(255),
    FieldExcavatorSubAggregateAssignment varchar(255),
    StratAggComment varchar(1000),
    ContiguousUnitsAbove varchar(255),
    ContiguousUnitsBelow varchar(255),
    EquivalentUnits varchar(255),
    GeneralDiagnosis varchar(1000),
    GenDiagExplanation longtext,
    BurnedFeature boolean,
    Residue boolean,
    Color varchar(255),
    Texture varchar(1000),
    MoistureLevel varchar(255),
    NaturalInclusions varchar(255),
    NaturalFormations varchar(255),
    Disturbances varchar(255),
    ArtEcoContents varchar(255),
    OtherComments varchar(1000),
    LotNumberNW int,
    LotNumberSW int,
    LotNumberNE int,
    LotNumberSE int,
    LotNumberOther varchar(255),
    BulkSampleNW varchar(255),
    BulkSampleSW varchar(255),
    BulkSampleNE varchar(255),
    BulkSampleSE varchar(255),
    BulkSampleNWTaken boolean,
    BulkSampleNWShotIn boolean,
    BulkSampleSWTaken boolean,
    BulkSampleSWShotIn boolean,
    BulkSampleNETaken boolean,
    BulkSampleNEShotIn boolean,
    BulkSampleSETaken boolean,
    BulkSampleSEShotIn boolean,
    `Mid-Strat` boolean,
    FinalOutline boolean,
    DirectorComments varchar(1000),
    PhotoSeriesNumbers int,
    PlanView varchar(1000),
    ProfileView varchar(1000),
    OtherPhotos varchar(1000)
);
    

CREATE TABLE IF NOT EXISTS upload_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    file_hash VARCHAR(64) UNIQUE,
    filename TEXT,
    upload_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_modified TIMESTAMP,
    is_synced INTEGER DEFAULT 0
);
""")

    conn.commit()
    conn.close()
    
    print("Offline dataBase initialized")