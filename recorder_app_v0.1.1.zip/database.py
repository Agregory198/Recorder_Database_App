# -*- coding: utf-8 -*-
"""
Created on Wed May 13 11:27:21 2026

@author: grego
"""

from pathlib import Path
from sqlalchemy import create_engine
import os

proj_dir = r'C:\Users\grego\OneDrive\Documents\Projects\Archaeo_RecorderTablet'
def get_db_path():
    #app_dir = Path(os.getenv("LOCALAPPDATA", Path.home())) / "ArchaeoApp"
    app_dir = Path(proj_dir)
    app_dir.mkdir(parents=True, exist_ok=True)
    return app_dir / "data/local.db"


def get_local_engine():
    db_path = get_db_path()
    return create_engine(f"sqlite:///{db_path}")
