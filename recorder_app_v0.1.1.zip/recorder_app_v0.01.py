# -*- coding: utf-8 -*-
"""
Created on Wed May 13 11:26:37 2026

@author: grego
"""

import streamlit as st
import pandas as pd
from sqlalchemy import inspect
from io import StringIO
import hashlib
from sqlalchemy import text, bindparam
from datetime import datetime
import os
import plotly.express as px
import narwhals.exceptions
from sqlalchemy.dialects.mysql import insert
from sqlalchemy import Table, MetaData
import numpy as np
from pathlib import Path
import sqlite3
from sqlalchemy.dialects.sqlite import insert as sqlite_insert
from sqlalchemy.exc import OperationalError
import shutil
from offline_table_creation import initialize_sqlite_DB
from sqlalchemy.dialects.mysql import insert as mysql_insert
from database import get_local_engine



date_str = datetime.now().strftime("%Y-%m-%d")

#APP_DIR = Path(os.getenv("LOCALAPPDATA", Path.home())) / "ArchaeoApp"
#APP_DIR.mkdir(exist_ok=True)

#db_path = APP_DIR / "local.db"

initialize_sqlite_DB()


engine = get_local_engine()
inspector = inspect(engine)


st.title("Recorder Tablet")

